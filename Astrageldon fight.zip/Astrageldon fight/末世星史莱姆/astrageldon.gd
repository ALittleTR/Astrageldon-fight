extends Node2D
@onready var battle_node = get_parent()
@onready var anim = $phase1
var monument = preload("res://bullets/monuments.tscn")
var speed = 1
var direction = Vector2(0,0)
var g = 0.03
var ground = 330
var fly = false
@onready var pos = get_parent().get_node("player").position
var angle = 0
@onready var player = battle_node.get_node("player")
	
func slow():
	var pos = battle_node.player.position.x
	while abs(position.x-pos) > 0:
			if position.x-pos > 0:
				direction.x -= 0.3
				if direction.x < 0:
					break
				await get_tree().process_frame
				
			else:
				direction.x += 0.3
				if direction.x > 0:
					break
				await get_tree().process_frame
var is_jumping = false
func smash(x):
	fly = false
	position.y -= 1
	is_jumping = true
	var offset = randf_range(-1,1)
	if offset == 0:
		offset += 0.001
	if x == 0:
		g = 0.1
		direction = Vector2(-1*(offset+position.x-battle_node.player.position.x)/abs(offset+position.x-battle_node.player.position.x),randf_range(-5,-6))
	elif x == 2:
		$pillar.show()
		$pillar.vis = 1
		$pillar.modulate.a = 0
		g = 0.1
		direction = Vector2(0,-5)
		direction.x = 0
		while is_jumping:
			if position.y >= 330:
				is_jumping = false
			await get_tree().process_frame
	else:
		$pillar.show()
		$pillar.vis = 1
		$pillar.modulate.a = 0
		g = 0.1
		direction = 	Vector2(-1.5*(offset+position.x-battle_node.player.position.x)/abs(offset+position.x-battle_node.player.position.x),randf_range(-9,-10))
		slow()
	while is_jumping:
		if x == 1 and abs(direction.y) <= 1:
			direction.y += 10
		if position.y >= 330:
			is_jumping = false
		await get_tree().process_frame
	if x == 1 or x == 2:
		var m_right = monument.instantiate()
		m_right.x = position.x;m_right.y = 1
		get_parent().get_node("bullets").add_child(m_right)
		var m_left = monument.instantiate()
		m_left.x = position.x;m_left.y = -1
		get_parent().get_node("bullets").add_child(m_left)
	direction = Vector2(0,0)
	$pillar.hide()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position = Vector2(320,170)
	$phase2.hide()
	anim.play()
	pass # Replace with function body.

var a = Vector2(0,0)
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:

	if battle_node.current_state == battle_node.State.Menu:
		position += (Vector2(320,170)-position)/30
	if battle_node.current_state == battle_node.State.Enemyturn:
		if fly == false:
			position.x = clamp(position.x,120,520)
			position.y = clamp(position.y,-999,330)
			position += speed*direction
			direction.y += g
			if position.y >= 330:
				position.y = 330
				direction = Vector2(0,0)
			if position.x <= 120 or position.x >= 520:
				direction.x = 0
				if abs(position.x-120)<abs(position.x-520):
					position.x = 120
				else:
					position.x = 520
		elif fly == true:
			if battle_node.round%4 == 1:
				position = position.lerp(a,0.05)
			elif battle_node.round%4 == 2:
				pos = get_parent().get_node("player").position
				position = position.lerp(Vector2(320,280)+150*Vector2(cos(angle),sin(angle)),0.005)
				angle += 0.01
	pass
