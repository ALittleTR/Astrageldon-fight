extends Node
var bosshp = 300000
var hp = 660
var stage: int = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("enventory") and Input.is_action_pressed("cancel") and Input.is_action_pressed("confirm"):
		hp += 300
	if bosshp <= 0:
		bosshp = 0
		stage = 2
	pass
