extends Sprite2D
@onready var boss = get_parent()
var vis = 0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	hide()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	scale.y = (375-boss.position.y)/411
	if vis == 1:
		scale.y = (375-boss.position.y)/411
		modulate.a += 0.01
	if modulate.a >= 0.8:
		modulate.a = 0.8
	pass	
