extends Node2D
@onready var menu = $Menu
@onready var buttons = $Menu.get_children()
@onready var boss = $Astrageldon
enum State{
	Menu,
	Action,
	Enemyturn,
	Gameover
}
func wait(i):
	await get_tree().create_timer(i).timeout
var round = -1
@onready var player = $player		
var slime = preload("res://bullets/astslime.tscn")
var meteor1 = preload("res://bullets/meteor.tscn")
var apstar = preload("res://bullets/apstar.tscn")
var menu_index = 0
var fight0 = preload("res://图片/Battle Screen/spr_fightbt_0.png")
var fight1 = preload("res://图片/Battle Screen/spr_fightbt_1.png")
var act0 = preload("res://图片/Battle Screen/spr_actbt_center_0.png")
var act1 = preload("res://图片/Battle Screen/spr_actbt_center_1.png")
var item0 = preload("res://图片/Battle Screen/spr_itembt_0.png")
var item1 = preload("res://图片/Battle Screen/spr_itembt_1.png")
var mercy0 = preload("res://图片/Battle Screen/spr_sparebt_0.png")
var mercy1 = preload("res://图片/Battle Screen/spr_sparebt_1.png")
var bosshp1 = preload("res://图片/紫薯1.png")
var bosshp2 = preload("res://图片/紫薯2.png")
var btnimage = [fight0,fight1,act0,act1,item0,item1,mercy0,mercy1]
var current_state = State.Menu
var menu_text = []
var act = 0
var is_attacking = false
func player_turn():
	$text.visible_ratio = 0
	is_attacking = false
	$fight.hide()
	act = 0
	$player.show()
	current_state = State.Menu
	round += 1
	$Menu.show()
	menu_index = 0
	$player.global_position = Vector2(39,433)
func do_action(i):
	var miss = 1
	var damage_factor = 0
	act = 1
	$player.hide()
	$fight/strike.hide()
	match i:
		0:
			is_attacking = true
			$fight.show()
			$fight/slider.position = Vector2(-280,0)
			$"fight/slider/1".show();$"fight/slider/2".show();$"fight/slider/3".hide();$"fight/slider/4".hide()
			for j in range(280):
				damage_factor += 1
				$fight/slider.position += Vector2(2,0)
				await get_tree().process_frame
				
				if Input.is_action_just_pressed("confirm"):
					miss = 0
					break
			if miss == 0:
				
				$fight/strike.show()
				$fight/strike.play()
				for j in range(7):
					$"fight/slider/3".show();$"fight/slider/4".show();$"fight/slider/1".hide();$"fight/slider/2".hide()
					await wait(0.1)
					$"fight/slider/1".show();$"fight/slider/2".show();$"fight/slider/3".hide();$"fight/slider/4".hide()
					await wait(0.1)
				if damage_factor == 140:
					Global.bosshp -= int(1.5*(13000+randi_range(-300,300))*2*(1-abs(140.0-damage_factor)/140.0))
					$fight/damage.text = "%d"%(int(1.5*(13000+randi_range(-300,300))*2*(1-abs(140.0-damage_factor)/140.0)))
					
				else:
					Global.bosshp -= int((13000+randi_range(-300,300))*(2-abs(140.0-damage_factor)/140.0))
					$fight/damage.text = "%d"%(int(13000+randi_range(-300,300))*(2-abs(140.0-damage_factor)/140.0))
				$fight/strike.stop()

				await $fight/damage.anim(1)
				for j in range(2):
					$"fight/slider/3".show();$"fight/slider/4".show();$"fight/slider/1".hide();$"fight/slider/2".hide()
					await wait(0.1)
					$"fight/slider/1".show();$"fight/slider/2".show();$"fight/slider/3".hide();$"fight/slider/4".hide()
					await wait(0.1)
			else:
				$fight/damage.text = "miss"
				await $fight/damage.anim(0)
			enemy_turn()
var roundtime = [3.0,2.0,2.0,3.0]	
func star():
	boss.fly = true
	var angle = randf_range(0,PI)
	for i in range(11):
		var star = apstar.instantiate()
		star.o = Vector2(110*cos(angle)-30,110*sin(angle))
		$bullets.add_child(star)
		angle += TAU/11
func enemy_turn():
	current_state = State.Enemyturn
	$player.position = Vector2(320,290)
	$player.show()
	$fight.hide()
	if round%4 == 0:
		for i in range(2):
			await boss.smash(0)
			await wait(1)
		for i in range(min(5,3+int(round/4))):
			await boss.smash(1)
			await wait(0.5)
		
	elif round%4 == 1:
		
		for i in range(4+int(round/8)):
			star()
			boss.a = $player.position+Vector2(randf_range(-150,150),randf_range(-180,-300))
			await get_tree().create_timer(2).timeout
		await boss.smash(2)
	elif round%4 == 2:
		boss.fly = true
		var angle = 0.3
		$Astrageldon.angle = 3*PI/2
		for i in range(15):			
			var meteor = meteor1.instantiate()
			meteor.verticle = 0
			meteor.angle = angle
			meteor.o = Vector2(200*cos(angle)-20,40*sin(angle))
			meteor.pos = $Astrageldon.position
			$bullets.add_child(meteor)
			angle += TAU/15
		for i in range(15):			
			var meteor = meteor1.instantiate()
			meteor.verticle = 1
			meteor.angle = angle
			meteor.angle1 = PI/2
			meteor.o = Vector2(200*cos(angle)-20,40*sin(angle)).rotated(PI/4)
			meteor.pos = $Astrageldon.position
			$bullets.add_child(meteor)
			angle += TAU/15
		await wait(10)
	elif round%4 == 3:

		await wait(0.5)
		for i in range(3):
			await boss.smash(2)
			await wait(0.3)
			for j in range(3):
				var slm = slime.instantiate()
				slm.position = boss.position+Vector2(0,-30)
				slm.fly = true
				slm.speed = Vector2(i*10+j*randf_range(3,6)-14,-40)
				$bullets.add_child(slm)
		boss.fly = true
		await create_tween().tween_property(boss,"position",Vector2(320,-300),0.05).finished
		await wait(5)
		boss.fly = false
		boss.direction = Vector2(0,0)
		await boss.smash(2)
	await wait(roundtime[round%4])
	for i in $bullets.get_children():
		i.queue_free()
	player_turn()

	
				
				
func box():
	if current_state == State.Menu:
		print(1)
		
# Called when the node enters the scene tree for the first time.
func update_menu_highlight():
	for i in range(4):
		var btn = buttons[i]
		if i == menu_index:
			btn.texture_normal = btnimage[2*i+1]
		else:
			btn.texture_normal = btnimage[2*i]


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if current_state == State.Gameover:
		$BGM.stream_paused
		$Gameover.show()
		for i in $bullets.get_children():
			i.queue_free()
	$bosshealth/bossbar.value += (Global.bosshp-$bosshealth/bossbar.value)*0.05
	$healthbar/bar.value = Global.hp
	$healthbar/Label.text = "生命：%d/660"%[Global.hp]
	$bosshealth/Label.text = "%d/300000"%[Global.bosshp]
	if current_state == State.Menu:
		update_menu_highlight()
		if Input.is_action_just_pressed("right"):
			menu_index = (menu_index + 1) % 4
			update_menu_highlight()
		if Input.is_action_just_pressed("left"):
			menu_index = (menu_index + 3) % 4
			update_menu_highlight()
		if Input.is_action_just_pressed("confirm"):
			if menu_index == 0:#等会要修改补全其他操作
				current_state = State.Action
	elif current_state == State.Action:
		if Input.is_action_just_pressed("cancel"):
			current_state = State.Menu
			$text.visible_ratio = 0
		elif Input.is_action_just_pressed("confirm") and act == 0:
			do_action(menu_index)
			
				
	pass
func _ready():
	$Gameover.hide()
	$fight/damage.hide()
	$fight.position = Vector2(320,330)
	$Menu.position = Vector2(24,410)
	player_turn()
	pass
