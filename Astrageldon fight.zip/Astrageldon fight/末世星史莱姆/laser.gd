extends Area2D
var direction = Vector2(0,0)
var d = direction
var speed = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var battle_node = get_parent().get_parent()
	if battle_node.round%4 != 1:
		queue_free()
	scale = Vector2(1.4,1.4)
	speed = 1
	rotation = direction.angle()
	show()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position += direction*speed
	if speed <= 12:
		speed += 0.2
	if scale.x <= 2:
		scale += Vector2(0.05,0.05)
	if position.x > 640 or position.x < 0 or position.y > 480 or position.y < 0:
		queue_free()
	pass
