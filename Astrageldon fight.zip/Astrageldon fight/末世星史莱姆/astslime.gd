extends Area2D
var g = 0.1
var rdirection: Vector2
var speed = Vector2(0,0)
var fly = true
var timer = 120
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	fly = true
	if get_parent().get_parent().round%4 != 3:
		queue_free()
	show()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if position.y < -600:
		speed.x = 0
		$smallpillar.show()
		$smallpillar.vis = 1
	position.x = clamp(position.x,25,545)
	position.y = clamp(position.y,-999,380)
	if fly == false:
		$smallpillar.hide()
		timer -= 1
		if timer <= 0:	
			fly = true	
			speed = Vector2(randf_range(-2,2),randf_range(-3,-7))
		return
	elif fly == true:
		position += speed
		speed.y += g
		if position.y >= 380:
			position.y = 380
			speed = Vector2(0,0)
			fly = false
			timer = randi_range(90,150)			
			$smallpillar.vis = 0
	pass
