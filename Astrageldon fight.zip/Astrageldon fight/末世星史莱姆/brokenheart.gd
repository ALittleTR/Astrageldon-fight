extends Node2D
var g = 0.1
var speed:Vector2
@onready var b = get_parent().battle_node
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	show
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:	
	position += speed
	speed.y += g
	if position.y >= 480:
		queue_free()
	pass
