extends NinePatchRect
@onready var battle_node = get_parent()

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if battle_node.current_state == battle_node.State.Menu or battle_node.current_state == battle_node.State.Action:			
		position = position.lerp(Vector2(620,400)-size,0.1)
		size = size.lerp(Vector2(600,140),0.1)
	elif battle_node.current_state == battle_node.State.Enemyturn:
		position = position.lerp(Vector2(620,400)-size,0.1)
		size = size.lerp(Vector2(600,220),0.1)
	pass
