extends Sprite2D
@onready var boss = get_parent()
var vis = 0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	modulate.a = 0
	hide()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if boss.fly == false:
		hide()
	scale.y = (350-boss.position.y)/94
	if vis == 1:
		modulate.a += 0.005
	if modulate.a >= 0.6:
		modulate.a = 0.6
	pass	
