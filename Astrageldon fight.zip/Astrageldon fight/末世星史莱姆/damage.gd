extends Label
@onready var battle_node = get_parent().get_parent()
@onready var bosshp = Global.bosshp
# Called when the node enters the scene tree for the first time.
var speed = 0
var g = 0.25
func _ready() -> void:

	pass # Replace with function body.
func anim(x):
	if x == 1:
		add_theme_color_override("font_color",Color(0.7,0.0,0.0,1.0))
		add_theme_color_override("font_outline_color",Color(0,0,0,1))
	else:
		add_theme_color_override("font_color",Color(0.3,0.3,0.3,1))
	show()
	speed = -5
	for i in range(42):
		position += speed*Vector2(0,1)
		speed += g
		await get_tree().process_frame
	await get_tree().create_timer(0.6).timeout
	hide()
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	pass
