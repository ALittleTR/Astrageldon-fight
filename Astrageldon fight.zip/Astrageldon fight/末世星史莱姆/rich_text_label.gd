extends RichTextLabel


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
@onready var battle_node = get_parent()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if battle_node.current_state == battle_node.State.Action and battle_node.is_attacking == false:
		if battle_node.menu_index == 0:
			
			show()
			position = Vector2(78,278)
	else:
		hide()
	pass
