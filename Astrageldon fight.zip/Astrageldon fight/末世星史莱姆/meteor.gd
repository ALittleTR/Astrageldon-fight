extends Area2D
var o = Vector2(0,0)
var pos: Vector2
var angle1 = 0
var angle = 0
var size = 1
var verticle = 0
var shape1 = 1
var t = 0
@onready var battle_node = get_parent().get_parent()
# Called when the node enters the scene tree for the first time.
func _ready() -> void:

	size = 0.1
	position = o
	scale = randf_range(0.5,1.3)*Vector2(1,1)
	show()
	
	if battle_node.round%4 != 2:
		queue_free()

	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	shape1 = sin(t)
	t += 0.005
	if angle-int(angle/(TAU))*TAU < PI:
		z_index = -1
	else:
		z_index = 1
	if size <= 1:
		size += 0.01
	if battle_node.round%4 != 2:
		queue_free()
	if size <= 1.9:
		size += 0.002
	angle1 += 0.012
	angle += 0.006
	position = size*Vector2(200*cos(angle),40*shape1*sin(angle)).rotated(angle1)+get_parent().get_parent().get_node("Astrageldon").position
	pass
