extends Node2D
var atk = 0
func bullet_attack(n):
	atk = n
	if n%4 == 0:
		print(1)
		

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if atk%4 == 0:
		position = Vector2(30,0)
		
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
