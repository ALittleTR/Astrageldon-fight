extends RichTextLabel
@onready var battle_node = get_parent()

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	visible_ratio = 0.0
	position = Vector2(58,278)
	pass # Replace with function body.

var typing = false
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if battle_node.current_state == battle_node.State.Menu:
		show()
	elif battle_node.current_state == battle_node.State.Action:
		if Input.is_action_just_pressed("cancel"):
			visible_ratio = 0
		hide()
	else:
		hide()
	if visible_ratio != 1:
		typing = true
	if typing:
		visible_ratio += 0.007
		if Input.is_action_just_pressed("confirm"):
			visible_ratio = 1
		if visible_ratio == 1:
			typing = false
	pass
