extends Area2D
var o = Vector2(0,0)
var l = preload("res://bullets/laser.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	show()
	create_tween().tween_property(self,"rotation_degrees",150,0.3)
	await get_tree().create_timer(0.5).timeout
	for i in range(3):
		var laser = l.instantiate()
		laser.position = position#+2*position+(position-get_parent().get_parent().get_node("Astrageldon").position).normalized().rotated(PI/2*(i)*(-1)**i)
		laser.direction = (position-get_parent().get_parent().get_node("Astrageldon").position).normalized().rotated(5*(i-1)*PI/180.0)
		get_parent().get_parent().get_node("bullets").add_child(laser)
	queue_free()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	show()
	position = o + get_parent().get_parent().get_node("Astrageldon").position
	pass
