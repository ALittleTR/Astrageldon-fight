extends CharacterBody2D
var direction: float
var speed: int = 10
var flytime = 60
var fly = 0
var g = 1
var yspeed = 0
var game = preload("res://图片/player.png")
var over = preload("res://图片/playerdie.png")
var brokenheart = preload("res://bullets/brokenheart.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	set_process(true)
	$soul.texture = game
	pass # Replace with function body.
@onready var battle_node = get_parent()
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func _physics_process(delta: float) -> void:
	if Global.hp <= 0:
		Global.hp = 0
		battle_node.current_state = battle_node.State.Gameover
	if battle_node.current_state == battle_node.State.Menu:
		position = Vector2(39+battle_node.menu_index*160,433)
	elif battle_node.current_state == battle_node.State.Action:
		position = Vector2(61,288)
	elif battle_node.current_state == battle_node.State.Gameover:
		$soul.texture = over
		await get_tree().create_timer(0.9).timeout
		hide()
		for i in range(randi_range(9,13)):
			var piece = brokenheart.instantiate()
			add_child(piece)
			piece.speed = Vector2(randf_range(-3,3),randf_range(-2,-3))
			piece.scale = Vector2(1,1)*randf_range(0.5,1.2)
		set_process(false)
		return
	elif battle_node.current_state == battle_node.State.Enemyturn:
		
		if Input.is_action_pressed("cancel"):
			speed = 3.5
		else:
			speed = 7
		direction = Input.get_axis("left","right")
		position += Vector2(1,0)*direction*speed + Vector2(0,-1)*fly
		position.x = clamp(position.x,40,600)
		position.y = clamp(position.y,210,380)
		fly = 0
		if position.y >= 380:
			yspeed = 0
			flytime = 100
		if position.y <= 210:
			yspeed = 0
		if Input.is_action_pressed("jump") and flytime >= 0:
			if yspeed >= 5:
				yspeed = 5
			g = 0
			if yspeed >= -10:
				yspeed += -1
				flytime -= 1
		else:
			g = 0.5
		if position.y != 380 and yspeed <= 10:
			yspeed += g
		position.y += yspeed
	pass
var invincible = false
func hurt(x):
	if invincible == true:
		return
	else:
		invincible = true
		Global.hp -= x
		var blink = $soul.create_tween()
		blink.set_loops(5)
		blink.tween_property($soul,"modulate:a",0.2,0.1)
		blink.tween_property($soul,"modulate:a",1.0,0.1)
		await blink.finished
		invincible = false
		$hitbox.position += Vector2(999,999)
		await get_tree().physics_frame;await get_tree().physics_frame
		$hitbox.position -= Vector2(999,999)
func _on_hitbox_area_entered(area: Area2D) -> void:
	if battle_node.current_state == battle_node.State.Enemyturn:
		hurt(100)
		
	pass # Replace with function body.
