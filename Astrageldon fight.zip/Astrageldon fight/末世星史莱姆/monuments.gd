extends Area2D
@onready var boss = get
var omega = 1
var t = 0
var x = 0
var y = 0
var monument = preload("res://bullets/monuments.tscn")
# Called when the node enters the scene tree for the first time.
func spawn(x,y):
	t = 0.3
	show()
	$Sprite2D.modulate.a = 1
	position.x = x + 10*y
	if position.x < 640 and position.x > 0:
		
		await get_tree().create_timer(0.07).timeout
		var m = monument.instantiate()
		m.x = position.x;m.y = y
		get_parent().get_parent().get_node("bullets").add_child(m)
	else:
		queue_free()
func _ready() -> void:
	
	position.y = 390
	spawn(x,y)
		
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	scale.y = sin(omega*t)
	t += 0.023
	if scale.y <= 0.4:
		$Sprite2D.modulate.a -= 0.01
	if scale.y <= 0.01:
		queue_free()
	pass
